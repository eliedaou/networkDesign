Team members
  Grant Moyer
  Elie Daou

Steps required to set up and execute this program
  0. Server.java and Client.java must be in the same directory
  1. Compile and run Server.java file
  2. Compile an run Client.java file

Files and purposes:
  1. Server.java initializes the server
  2. Client.java initializes the server
